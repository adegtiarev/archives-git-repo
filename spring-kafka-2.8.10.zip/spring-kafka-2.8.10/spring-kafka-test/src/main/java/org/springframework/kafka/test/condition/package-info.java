/**
 * Provides classes for JUnit5 conditions.
 */
package org.springframework.kafka.test.condition;
