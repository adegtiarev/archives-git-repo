/**
 * Provides classes for adapting listeners.
 */
@org.springframework.lang.NonNullApi
package org.springframework.kafka.listener.adapter;
