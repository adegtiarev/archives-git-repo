/**
 * Provides classes related to transactions.
 */
package org.springframework.kafka.transaction;
